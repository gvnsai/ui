import React from 'react'

const PageOne = React.createClass({
  render() {
    return <h2>Page One!</h2>
  }
})

export default PageOne
