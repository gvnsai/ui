import React from 'react'

const About = React.createClass({
  render() {
    return <h1>About</h1>
  }
})

export default About
