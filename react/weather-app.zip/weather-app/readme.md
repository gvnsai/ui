React Weather Application
