

export const add_User= (email) =>{
 console.log("hai");
return {
  type:'ADD_USER',
  payload: [email],
}

}
