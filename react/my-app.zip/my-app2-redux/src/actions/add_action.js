export const  add=(name, email)=>{
  console.log("hai",name);

  return {
    type: "ADD",
    payload: {userName: name, email: email}
  }
}
