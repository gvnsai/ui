
const intState=[
  {userName:"ABCD",email:"abcd@gmail.com"},
  {userName:"EFGH",email:"efgh@gmail.com"},
  {userName:"IJKL",email:"ijkl@gmail.com"},
]

  const userReducer=(state=intState,action)=>{
  switch (action.type) {
    case 'ADD':
       return [...state, action.payload]
    case 'REM':
       return { ...state };

    default:
       return state;

  }

}

/*export default function(){

return [
    {userName:"ABCD",email:"abcd@gmail.com"},
    {userName:"EFGH",email:"efgh@gmail.com"},
    {userName:"IJKL",email:"ijkl@gmail.com"},

]

}*/
export default userReducer;
